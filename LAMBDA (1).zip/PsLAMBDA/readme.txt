Folder containing scripts / routines for computing success rates. 

